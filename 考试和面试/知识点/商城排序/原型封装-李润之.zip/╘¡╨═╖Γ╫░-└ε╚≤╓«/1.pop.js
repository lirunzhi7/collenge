

// Array.prototype.pop=function(){
//     var cur = this[this.length-1]
//     cur.length--
//     return cur
// }
